class SATSolver;

#ifndef SATSOLVER_H
#define SATSOLVER_H

#include <fstream>

#include "SAT.h"

using namespace std;

struct ReturnValue
{
	unsigned long long Trues;
	unsigned long long Falses;
	unsigned long long Unknowns;
	list<list<int> *> * Result;
};

struct Pair
{
	bool Return;
	list<int> * Result;
	list<unsigned int> * Equalility;
	list<unsigned int> * Undecidable;
};

struct DepthPair
{
	int Return;
	unsigned long long EvalCount;
	list<int> * Result;
};

#define DEPTH
//#define DEPTH_USES_FLIP
//#define FLIP
//#define FAST

//#define ORGINAL_SET
#define SECONDARY_SET

#ifdef _DEBUG
#define MAX_DEPTH_LIMIT 10
#else
#define MAX_DEPTH_LIMIT 250000
#endif

class SATSolver
{
private:
	SAT * sat;
public:
	SATSolver(SAT * sat);
	~SATSolver();
	//list <string> & SlowSat();
	ReturnValue SolveTruth(ofstream & file) const;
	ReturnValue ParallelSolveTruth(ofstream & file) const;
	list<int> * StopAtFirstTruth(ofstream & file) const;
	list<int> * ParallelStopAtFirstTruth(ofstream & file) const;
};

#endif