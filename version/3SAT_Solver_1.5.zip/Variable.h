class Variable;

#ifndef VARIABLE_H
#define VARIABLE_H

#include "Literal.h"
#include "SAT.h"

using namespace std;

struct VariableState
{
	unsigned int NegativesSize;
	unsigned int PositivesSize;
	unsigned int SmallestNegativeClauseSize;
	unsigned int SmallestNegativeClauseCount;
	unsigned int SmallestPositiveClauseCount;
	unsigned int SmallestPositiveClauseSize;
	unsigned int LargestNegativeClauseSize;
	unsigned int LargestNegativeClauseCount;
	unsigned int LargestPositiveClauseSize;
	unsigned int LargestPositiveClauseCount;
};

class Variable
{
private:
	int Variable_Number;
	bool WentPositive;
	bool isEvaluated;
	list <Literal *> Negatives;
	list <Literal *> Positives;
	list <Literal *> InactiveNegatives;
	list <Literal *> InactivePositives;
	list <VariableState> PreviousStates;
	VariableState CurrentState;

	SAT * _parent;
	bool isActive;
	list <Variable *>::const_iterator listPointer;
public:

	//Constructors
	Variable(const int Variable_Number, SAT * _parent);
	~Variable();

	//Modifiers
	void Revert();
	void StepBack();
	bool Flip();
	bool Undo();
	void Add(Literal * lit);
	void Remove(list <Literal *>::const_iterator litIter);
	void Add(list <Literal *>::const_iterator lit);
	void Subtract(list <Literal *>::const_iterator lit);
	void Remove(bool isPositive);
	void Set();
	void Update();
	void SetListPointer(list <Variable *>::const_iterator var, bool isActive);

	//Operations
	bool IsEvaluated() const;
	int GetVariable() const;
	bool IsActive() const;
	int GetValue() const;
	unsigned int LargestNumber() const;
	unsigned int SmallestNumber() const;
	unsigned int GetDifference() const;
	unsigned int SmallestClauseSize() const;
	unsigned int SmallestClauseCount() const;
	unsigned int LargestClauseSize() const;
	unsigned int LargestClauseCount() const;

	unsigned int GetNegativesSize() const;
	unsigned int GetPositivesSize() const;
	unsigned int GetSmallestNegativeClauseSize() const;
	unsigned int GetSmallestNegativeClauseCount() const;
	unsigned int GetSmallestPositiveClauseCount() const;
	unsigned int GetSmallestPositiveClauseSize() const;
	unsigned int GetLargestNegativeClauseSize() const;
	unsigned int GetLargestNegativeClauseCount() const;
	unsigned int GetLargestPositiveClauseSize() const;
	unsigned int GetLargestPositiveClauseCount() const;

	//Operator Overloads
	bool operator==(const Variable & variable) const;
	bool operator!=(const Variable & variable) const;
	bool operator<(const Variable & variable) const;
	bool operator>(const Variable & variable) const;
	bool operator<=(const Variable & variable) const;
	bool operator>=(const Variable & variable) const;
};

#endif