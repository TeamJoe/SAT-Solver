class SATSolver;

#ifndef SATSOLVER_H
#define SATSOLVER_H

#include <fstream>

#include "SAT.h"

using namespace std;

struct ReturnValue
{
	unsigned long long Trues;
	unsigned long long Falses;
	unsigned long long Unknowns;
};

struct Pair
{
	bool Return;
	list<int> * Result;
	list<unsigned int> * Equalility;
	list<unsigned int> * Undecidable;
};

struct DepthPair
{
	bool Return;
	unsigned long long EvalCount;
	list<int> * Result;
};

class SATSolver
{
private:
	SAT * sat;
	DepthPair * DepthSat(int (Decider)(Variable *), const list <SortFunction *> * SortFunctions) const;
	unsigned long long _DepthSat(int (Decider)(Variable *), const list <SortFunction *> * SortFunctions, list<int> * Result) const;
	Pair * FastSat(int (Decider)(Variable *), const list <SortFunction *> * SortFunctions) const;
public:
	SATSolver(SAT * sat);
	~SATSolver();
	//list <string> & SlowSat();
	ReturnValue SATSolver::SolveTruth(ofstream & file) const;
};

#endif