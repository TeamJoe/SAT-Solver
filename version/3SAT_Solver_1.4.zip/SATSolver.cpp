#include <list>
#include <fstream>
#include <iostream>

#include "Variable.h"
#include "SAT.h"
#include "SATSolver.h"

//For checking that all output is correct
#include <assert.h>

//Memory leak detection
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#include "Debug.h"

#ifdef _DEBUG
#define new DEBUG_CLIENTBLOCK
#endif

using namespace std;

//******************************
//------------------------------
//
// Sorting Functions
//
//------------------------------
//******************************
Variable * LeastDifference(Variable * v1, Variable * v2)
{
	if(v1->GetDifference() > 0 && v2->GetDifference() > 0)
	{
		return v1->GetDifference() < v2->GetDifference() ? v1 : v2;
	}
	return v1->GetDifference() > 0 ? v1 : v2;	
}

Variable * LeastSmallUsed(Variable * v1, Variable * v2)
{
	return v1->SmallestNumber() < v2->SmallestNumber() ? v1 : v2;
}

Variable * LeastLargeUsed(Variable * v1, Variable * v2)
{
	return v1->LargestNumber() < v2->LargestNumber() ? v1 : v2;
}

Variable * MostDifference(Variable * v1, Variable * v2)
{
	return v1->GetDifference() > v2->GetDifference() ? v1 : v2;
}

Variable * MostSmallUsed(Variable * v1, Variable * v2)
{
	return v1->SmallestNumber() > v2->SmallestNumber() ? v1 : v2;
}

Variable * MostLargeUsed(Variable * v1, Variable * v2)
{
	return v1->LargestNumber() > v2->LargestNumber() ? v1 : v2;
}

Variable * LeastSmallestClauseSize(Variable * v1, Variable * v2)
{
	return v1->SmallestClauseSize() < v2->SmallestClauseSize() ? v1 : v2;
}

Variable * LeastSmallestClauseCount(Variable * v1, Variable * v2)
{
	return v1->SmallestClauseCount() < v2->SmallestClauseCount() ? v1 : v2;
}

Variable * LeastLargestClauseSize(Variable * v1, Variable * v2)
{
	return v1->LargestClauseSize() < v2->LargestClauseSize() ? v1 : v2;
}

Variable * LeastLargestClauseCount(Variable * v1, Variable * v2)
{
	return v1->LargestClauseCount() < v2->LargestClauseCount() ? v1 : v2;
}

Variable * MostSmallestClauseSize(Variable * v1, Variable * v2)
{
	return v1->SmallestClauseSize() > v2->SmallestClauseSize() ? v1 : v2;
}

Variable * MostSmallestClauseCount(Variable * v1, Variable * v2)
{
	return v1->SmallestClauseCount() > v2->SmallestClauseCount() ? v1 : v2;
}

Variable * MostLargestClauseSize(Variable * v1, Variable * v2)
{
	return v1->LargestClauseSize() > v2->LargestClauseSize() ? v1 : v2;
}

Variable * MostLargestClauseCount(Variable * v1, Variable * v2)
{
	return v1->LargestClauseCount() > v2->LargestClauseCount() ? v1 : v2;
}

Variable * MostSmallestNegativeClauseSize(Variable * v1, Variable * v2)
{
	return v1->GetSmallestNegativeClauseSize() > v2->GetSmallestNegativeClauseSize() ? v1 : v2;
}

Variable * LeastSmallestNegativeClauseSize(Variable * v1, Variable * v2)
{
	return v1->GetSmallestNegativeClauseSize() < v2->GetSmallestNegativeClauseSize() ? v1 : v2;
}

Variable * MostSmallestNegativeClauseCount(Variable * v1, Variable * v2)
{
	return v1->GetSmallestNegativeClauseCount() > v2->GetSmallestNegativeClauseCount() ? v1 : v2;
}

Variable * LeastSmallestNegativeClauseCount(Variable * v1, Variable * v2)
{
	return v1->GetSmallestNegativeClauseCount() < v2->GetSmallestNegativeClauseCount() ? v1 : v2;
}

Variable * MostLargestNegativeClauseSize(Variable * v1, Variable * v2)
{
	return v1->GetLargestNegativeClauseSize() > v2->GetLargestNegativeClauseSize() ? v1 : v2;
}

Variable * LeastLargestNegativeClauseSize(Variable * v1, Variable * v2)
{
	return v1->GetLargestNegativeClauseSize() < v2->GetLargestNegativeClauseSize() ? v1 : v2;
}

Variable * MostLargestNegativeClauseCount(Variable * v1, Variable * v2)
{
	return v1->GetLargestNegativeClauseCount() > v2->GetLargestNegativeClauseCount() ? v1 : v2;
}

Variable * LeastLargestNegativeClauseCount(Variable * v1, Variable * v2)
{
	return v1->GetLargestNegativeClauseCount() < v2->GetLargestNegativeClauseCount() ? v1 : v2;
}

Variable * MostSmallestPositiveClauseSize(Variable * v1, Variable * v2)
{
	return v1->GetSmallestPositiveClauseSize() > v2->GetSmallestPositiveClauseSize() ? v1 : v2;
}

Variable * LeastSmallestPositiveClauseSize(Variable * v1, Variable * v2)
{
	return v1->GetSmallestPositiveClauseSize() < v2->GetSmallestPositiveClauseSize() ? v1 : v2;
}

Variable * MostSmallestPositiveClauseCount(Variable * v1, Variable * v2)
{
	return v1->GetSmallestPositiveClauseCount() > v2->GetSmallestPositiveClauseCount() ? v1 : v2;
}

Variable * LeastSmallestPositiveClauseCount(Variable * v1, Variable * v2)
{
	return v1->GetSmallestPositiveClauseCount() < v2->GetSmallestPositiveClauseCount() ? v1 : v2;
}

Variable * MostLargestPositiveClauseSize(Variable * v1, Variable * v2)
{
	return v1->GetLargestPositiveClauseSize() > v2->GetLargestPositiveClauseSize() ? v1 : v2;
}

Variable * LeastLargestPositiveClauseSize(Variable * v1, Variable * v2)
{
	return v1->GetLargestPositiveClauseSize() < v2->GetLargestPositiveClauseSize() ? v1 : v2;
}

Variable * MostLargestPositiveClauseCount(Variable * v1, Variable * v2)
{
	return v1->GetLargestPositiveClauseCount() > v2->GetLargestPositiveClauseCount() ? v1 : v2;
}

Variable * LeastLargestPositiveClauseCount(Variable * v1, Variable * v2)
{
	return v1->GetLargestPositiveClauseCount() < v2->GetLargestPositiveClauseCount() ? v1 : v2;
}

//******************************
//------------------------------
//
// Equaility Functions
//
//------------------------------
//******************************

bool LargeUsed(const Variable * v1, const Variable * v2)
{
	return v1->LargestNumber() == v2->LargestNumber();
}

bool Difference(const Variable * v1, const Variable * v2)
{
	return v1->GetDifference() == v2->GetDifference();
}

bool SmallUsed(const Variable * v1, const Variable * v2)
{
	return v1->SmallestNumber() == v2->SmallestNumber();
}

bool SmallestClauseSize(const Variable * v1, const Variable * v2)
{
	return v1->SmallestClauseSize() == v2->SmallestClauseSize();
}

bool SmallestClauseCount(const Variable * v1, const Variable * v2)
{
	return v1->SmallestClauseCount() == v2->SmallestClauseCount();
}

bool LargestClauseSize(const Variable * v1, const Variable * v2)
{
	return v1->LargestClauseSize() == v2->LargestClauseSize();
}

bool LargestClauseCount(const Variable * v1, const Variable * v2)
{
	return v1->LargestClauseCount() == v2->LargestClauseCount();
}

bool SmallestNegativeClauseSize(const Variable * v1, const Variable * v2)
{
	return v1->GetSmallestNegativeClauseSize() == v2->GetSmallestNegativeClauseSize();
}

bool SmallestNegativeClauseCount(const Variable * v1, const Variable * v2)
{
	return v1->GetSmallestNegativeClauseCount() == v2->GetSmallestNegativeClauseCount();
}

bool LargestNegativeClauseSize(const Variable * v1, const Variable * v2)
{
	return v1->GetLargestNegativeClauseSize() == v2->GetLargestNegativeClauseSize();
}

bool LargestNegativeClauseCount(const Variable * v1, const Variable * v2)
{
	return v1->GetLargestNegativeClauseCount() == v2->GetLargestNegativeClauseCount();
}

bool SmallestPositiveClauseSize(const Variable * v1, const Variable * v2)
{
	return v1->GetSmallestPositiveClauseSize() == v2->GetSmallestPositiveClauseSize();
}

bool SmallestPositiveClauseCount(const Variable * v1, const Variable * v2)
{
	return v1->GetSmallestPositiveClauseCount() == v2->GetSmallestPositiveClauseCount();
}

bool LargestPositiveClauseSize(const Variable * v1, const Variable * v2)
{
	return v1->GetLargestPositiveClauseSize() == v2->GetLargestPositiveClauseSize();
}

bool LargestPositiveClauseCount(const Variable * v1, const Variable * v2)
{
	return v1->GetLargestPositiveClauseCount() == v2->GetLargestPositiveClauseCount();
}


//******************************
//------------------------------
//
// Find Variable Value
//
//------------------------------
//******************************
int Default(Variable * v1)
{
	if(v1->GetLargestNegativeClauseSize() == 1 && v1->GetLargestPositiveClauseSize() == 1)
	{
		//Means no solution
		return -1;
	}
	else if(v1->GetLargestNegativeClauseSize() == 1)
	{
		return -1;
	}
	else if(v1->GetLargestPositiveClauseSize() == 1)
	{
		return 1;
	}
	else if(v1->GetPositivesSize() == v1->GetNegativesSize())
	{
		return 0;
	}
	else
	{
		return v1->GetPositivesSize() > v1->GetNegativesSize()
			? 1
			: -1;
	}
}


//******************************
//------------------------------
//
// CONSTRUCTORS
//
//------------------------------
//******************************
SATSolver::SATSolver(SAT * sat)
{
	this->sat = sat;
}
SATSolver::~SATSolver()
{
	assert(this->sat);
	this->sat->cleanVariables();
	this->sat->cleanClauses();
	this->sat = NULL;
}

//******************************
//------------------------------
//
// PRIVATE FUNCTIONS
//
//------------------------------
//******************************
/*list <string> & SATSolver::SlowSat()
{
	stringstream var;
	for(list <char>::const_iterator i = Variables.cbegin(); i != Variables.cend(); i++)
	{
		var << *i;
	}
	string variables = var.str();
	list <string> * Returns = new list <string>;

	unsigned int max = 1 << variables.size();
	bool match = false;
	for(unsigned int x = 0; x < max; x++)
	{
		for(unsigned int y = 0; y < variables.size(); y++)
		{
			if(((x >> y) % 2) == 1)
			{
				//variables[y] = ToUpper(variables[y]);
			}
			else
			{
				//variables[y] = ToLower(variables[y]);
			}
		}

		match = true;
		for(list <SAT>::const_iterator i = Clauses.cbegin(); i != Clauses.cend(); i++)
		{
			if(!i->evaluate(variables))
			{
				match = false;
				break;
			}
		}
		if(match)
		{
			Returns->push_back(variables);
		}
	}
	return (*Returns);
}*/

DepthPair * SATSolver::DepthSat(int (Decider)(Variable *), const list <SortFunction *> * SortFunctions) const
{
	list<int> * Result = new list<int>();

	DepthPair * a = new DepthPair;
	a->Result = Result;
	a->EvalCount = this->_DepthSat(Decider, SortFunctions, Result, 0);
	if(this->sat->ClauseCount() == 0)
	{
		assert(this->sat->AllClausesHaveTrue());
		a->Return = true;
	}
	else
	{
		assert(!this->sat->AllClausesHaveTrue());
		assert(!this->sat->AllClausesHaveFalse());
		a->Return = false;
	}
	this->sat->Revert();
	return a;
}

#define MAX_LIMIT 10000
unsigned long long SATSolver::_DepthSat(int (Decider)(Variable *), const list <SortFunction *> * SortFunctions, list<int> * Result, unsigned long long currentCount) const
{
	if(this->sat->VariableCount() < 1)
	{
		if(this->sat->ClauseCount() != 0 && this->sat->AllClausesHaveFalse())
		{
			this->sat->FlipAll();

			assert(this->sat->ClauseCount() == 0);
			assert(this->sat->AllClausesHaveTrue());

			for(unsigned int i = 0; i < Result->size(); i++)
			{
				int y = Result->front();
				Result->pop_front();
				Result->push_back(-1 * y);

				assert(Result->back() != 0);
			}
		}
		return 0;
	}

	//Allow current chain to be evaluated
	/*if(MAX_LIMIT < currentCount)
	{
		return 0;
	}*/

	this->sat->UpdateVariables();
	this->sat->SetVariables();

	Variable * var1 = this->sat->NextVariable(SortFunctions);

	//Get best variable
	int solution = Decider(var1);

	this->sat->RemoveVariable(var1, solution > 0);
	Result->push_back(var1->GetValue());

	assert(var1->GetValue() != 0);
	assert(Result->back() == var1->GetValue());

	unsigned long long EvalCount = 1;
	EvalCount += this->_DepthSat(Decider, SortFunctions, Result, currentCount + EvalCount);

	if(MAX_LIMIT < (currentCount + EvalCount))
	{
		return EvalCount;
	}

	if(this->sat->ClauseCount() != 0)
	{
		Result->pop_back();
		this->sat->StepBackVariables();
		this->sat->UpdateVariables();
		this->sat->FlipVariable(var1);
		Result->push_back(var1->GetValue());

		assert(var1->GetValue() != 0);
		assert(Result->back() == var1->GetValue());

		EvalCount++;
		EvalCount += this->_DepthSat(Decider, SortFunctions, Result, currentCount + EvalCount);

		if(this->sat->ClauseCount() != 0)
		{
			Result->pop_back();
			this->sat->StepBackVariables();
			this->sat->UpdateVariables();
			this->sat->UndoVariable(var1);
		}
	}

	return EvalCount;
}

Pair * SATSolver::FastSat(int (Decider)(Variable *), const list <SortFunction *> * SortFunctions) const
{
	//Occurs when the program cannot decide what value to give a variable
	list<unsigned int> * Equalility = new list<unsigned int>();

	//Occurs when the program cannot decide what variable to evaluate next 
	list<unsigned int> * Undecidable = new list<unsigned int>();
	list<int> * Result = new list<int>();
	unsigned int y = 0;

	while(this->sat->VariableCount() > 0)
	{
		this->sat->UpdateVariables();
		this->sat->SetVariables();

		y++;
		Variable * var1 = this->sat->NextVariable(SortFunctions);
		Variable * var2 = this->sat->NextVariable(var1, SortFunctions);

		if(this->sat->Sort(var1, var2, SortFunctions) != var1 || this->sat->Sort(var2, var1, SortFunctions) != var1)
		{
			Undecidable->push_back(y);
		}

		//Get best variable
		int solution = Decider(var1);

		if(solution == 0)
		{
			solution = 1;
			Equalility->push_back(y);
		}

		this->sat->RemoveVariable(var1, solution > 0);
		Result->push_back(var1->GetValue());
		assert(var1->GetValue() != 0);
		assert(Result->back() == var1->GetValue());
	}

	if(this->sat->ClauseCount() != 0 && this->sat->AllClausesHaveFalse())
	{
		for(unsigned int i = 0; i < Result->size(); i++)
		{
			int y = Result->front();
			Result->pop_front();
			Result->push_back(-1 * y);

			assert(Result->back() != 0);
		}
	}

	Pair * a = new Pair;
	a->Result = Result;
	a->Equalility = Equalility;
	a->Undecidable = Undecidable;
	if(this->sat->ClauseCount() == 0)
	{
		assert(this->sat->AllClausesHaveTrue());
		a->Return = true;
	}
	else
	{
		a->Return = false;
	}
	this->sat->Revert();
	return a;
}

//#define DEPTH
ReturnValue SATSolver::SolveTruth(ofstream & file) const
{
	//Naming Convention
	//Least - Smallest number (So LeastSmallest is not the largest of the smallest, it is the smallest of the smallest numbers)
	//Most - Largest number (So the opposite of least)
	SortFunction AllFunctions[] = 
		{
			{LargeUsed, MostLargeUsed}, //0
			{LargeUsed, LeastLargeUsed}, //1
			{SmallUsed, MostSmallUsed}, //2
			{SmallUsed, LeastSmallUsed}, //3
			{Difference, MostDifference}, //4
			{Difference, LeastDifference}, //5
			{SmallestClauseSize, MostSmallestClauseSize}, //6
			{SmallestClauseSize, LeastSmallestClauseSize}, //7
			{SmallestClauseCount, MostSmallestClauseCount}, //8
			{SmallestClauseCount, LeastSmallestClauseCount}, //9
			{LargestClauseSize, MostLargestClauseSize}, //10
			{LargestClauseSize, LeastLargestClauseSize}, //11
			{LargestClauseCount, MostLargestClauseCount}, //12
			{LargestClauseCount, LeastLargestClauseCount} //13
			/*{SmallestNegativeClauseSize, MostSmallestNegativeClauseSize}, //14
			{SmallestNegativeClauseSize, LeastSmallestNegativeClauseSize}, //15
			{SmallestNegativeClauseCount, MostSmallestNegativeClauseCount}, //16
			{SmallestNegativeClauseCount, LeastSmallestNegativeClauseCount}, //17
			{LargestNegativeClauseSize, MostLargestNegativeClauseSize}, //18
			{LargestNegativeClauseSize, LeastLargestNegativeClauseSize}, //19
			{LargestNegativeClauseCount, MostLargestNegativeClauseCount}, //20
			{LargestNegativeClauseCount, LeastLargestNegativeClauseCount}, //21
			{SmallestPositiveClauseSize, MostSmallestPositiveClauseSize}, //22
			{SmallestPositiveClauseSize, LeastSmallestPositiveClauseSize}, //23
			{SmallestPositiveClauseCount, MostSmallestPositiveClauseCount}, //24
			{SmallestPositiveClauseCount, LeastSmallestPositiveClauseCount}, //25
			{LargestPositiveClauseSize, MostLargestPositiveClauseSize}, //26
			{LargestPositiveClauseSize, LeastLargestPositiveClauseSize}, //27
			{LargestPositiveClauseCount, MostLargestPositiveClauseCount}, //28
			{LargestPositiveClauseCount, LeastLargestPositiveClauseCount} //29*/
		};

	list <SortFunction *> SortList;

#ifdef DEPTH
	list <DepthPair *> Results;
#else
	list <Pair *> Results;
#endif

	//******************************
	//------------------------------
	//
	// Orginal Set
	//
	//------------------------------
	//******************************

	/*

	//MostDifference, MostLargeUsed
	SortList.clear();
	SortList.push_back(&AllFunctions[4]); SortList.push_back(&AllFunctions[0]); 
	Results.push_back(FastSat(Default, &SortList));

	//MostDifference, LeastLargeUsed
	SortList.clear();
	SortList.push_back(&AllFunctions[4]); SortList.push_back(&AllFunctions[1]); 
	Results.push_back(FastSat(Default, &SortList));

	//LeastDifference, MostLargeUsed
	SortList.clear();
	SortList.push_back(&AllFunctions[5]); SortList.push_back(&AllFunctions[0]); 
	Results.push_back(FastSat(Default, &SortList));

	//LeastDifference, LeastLargeUsed
	SortList.clear();
	SortList.push_back(&AllFunctions[5]); SortList.push_back(&AllFunctions[1]); 
	Results.push_back(FastSat(Default, &SortList));
	
	//MostLargeUsed, MostDifference
	SortList.clear();
	SortList.push_back(&AllFunctions[0]); SortList.push_back(&AllFunctions[4]); 
	Results.push_back(FastSat(Default, &SortList));

	//LeastLargeUsed, MostDifference
	SortList.clear();
	SortList.push_back(&AllFunctions[1]); SortList.push_back(&AllFunctions[4]); 
	Results.push_back(FastSat(Default, &SortList));

	//MostLargeUsed, LeastDifference
	SortList.clear();
	SortList.push_back(&AllFunctions[0]); SortList.push_back(&AllFunctions[5]); 
	Results.push_back(FastSat(Default, &SortList));

	//LeastLargeUsed, LeastDifference
	SortList.clear();
	SortList.push_back(&AllFunctions[1]); SortList.push_back(&AllFunctions[5]); 
	Results.push_back(FastSat(Default, &SortList));
	
	//*/

	//******************************
	//------------------------------
	//
	// Secondary Set
	//
	//------------------------------
	//******************************

#ifdef DEPTH
#define SAT_FUNCTION DepthSat
#else
#define SAT_FUNCTION FastSat
#endif
	
	//#1
	//LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount, MostDifference, MostLargeUsed
	SortList.clear();
	SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); SortList.push_back(&AllFunctions[4]); SortList.push_back(&AllFunctions[0]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));

	//#2
	//LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount, MostDifference, LeastLargeUsed
	SortList.clear();
	SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); SortList.push_back(&AllFunctions[4]); SortList.push_back(&AllFunctions[1]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));

	//#3
	//LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount, LeastDifference, MostLargeUsed
	SortList.clear();
	SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); SortList.push_back(&AllFunctions[5]); SortList.push_back(&AllFunctions[0]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));

	//#4
	//LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount, LeastDifference, LeastLargeUsed
	SortList.clear();
	SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); SortList.push_back(&AllFunctions[5]); SortList.push_back(&AllFunctions[1]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));
	
	//#5
	//LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount, MostLargeUsed, MostDifference
	SortList.clear();
	SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); SortList.push_back(&AllFunctions[0]); SortList.push_back(&AllFunctions[4]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));

	//#6
	//LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount, LeastLargeUsed, MostDifference
	SortList.clear();
	SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); SortList.push_back(&AllFunctions[1]); SortList.push_back(&AllFunctions[4]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));

	//#7
	//LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount, MostLargeUsed, LeastDifference
	SortList.clear();
	SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); SortList.push_back(&AllFunctions[0]); SortList.push_back(&AllFunctions[5]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));

	//#8
	//LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount, LeastLargeUsed, LeastDifference
	SortList.clear();
	SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); SortList.push_back(&AllFunctions[1]); SortList.push_back(&AllFunctions[5]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));

	//#9
	//MostDifference, MostLargeUsed, LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount
	SortList.clear();
	SortList.push_back(&AllFunctions[4]); SortList.push_back(&AllFunctions[0]); SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));

	//#10
	//MostDifference, LeastLargeUsed, LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount
	SortList.clear();
	SortList.push_back(&AllFunctions[4]); SortList.push_back(&AllFunctions[1]); SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));

	//#11
	//LeastDifference, MostLargeUsed, LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount
	SortList.clear();
	SortList.push_back(&AllFunctions[5]); SortList.push_back(&AllFunctions[0]); SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));

	//#12
	//LeastDifference, LeastLargeUsed, LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount
	SortList.clear();
	SortList.push_back(&AllFunctions[5]); SortList.push_back(&AllFunctions[1]); SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));
	
	//#13
	//MostLargeUsed, MostDifference, LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount
	SortList.clear();
	SortList.push_back(&AllFunctions[0]); SortList.push_back(&AllFunctions[4]); SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));

	//#14
	//LeastLargeUsed, MostDifference, LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount
	SortList.clear();
	SortList.push_back(&AllFunctions[1]); SortList.push_back(&AllFunctions[4]); SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));

	//#15
	//MostLargeUsed, LeastDifference, LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount
	SortList.clear();
	SortList.push_back(&AllFunctions[0]); SortList.push_back(&AllFunctions[5]); SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));

	//#16
	//LeastLargeUsed, LeastDifference, LeastSmallestClauseSize, MostSmallestClauseCount, LeastLargestClauseSize, MostLargestClauseCount
	SortList.clear();
	SortList.push_back(&AllFunctions[1]); SortList.push_back(&AllFunctions[5]); SortList.push_back(&AllFunctions[7]); SortList.push_back(&AllFunctions[8]); SortList.push_back(&AllFunctions[11]); SortList.push_back(&AllFunctions[12]); 
	Results.push_back(SAT_FUNCTION(Default, &SortList));
	
	//*/

	//******************************
	//------------------------------
	//
	// Remaining Program
	//
	//------------------------------
	//******************************
#ifdef DEPTH
	ReturnValue output;
	output.Falses = 0;
	output.Trues = 0;
	output.Unknowns = 0;

	unsigned int i = 0;
	for(list <DepthPair *>::const_iterator iter = Results.cbegin(); iter != Results.cend(); iter++)
	{
		if((*iter)->Return)
		{
			file << "1";
			output.Trues += (unsigned long long)1 << (unsigned long long)i;
			assert(this->sat->Evaluate((*iter)->Result));
		}
		else
		{
			file << "-1";
			output.Falses += (unsigned long long)1 << (unsigned long long)i;
			assert(!this->sat->Evaluate((*iter)->Result));
		}

		list<unsigned int>::iterator y;

		file << "(";

		file << (*iter)->EvalCount;

		file << ")";

		file << ",";
		delete (*iter)->Result;
		delete (*iter);

		i++;
	}
	return output;
#else
	ReturnValue output;
	output.Falses = 0;
	output.Trues = 0;
	output.Unknowns = 0;

	unsigned int i = 0;
	for(list <Pair *>::const_iterator iter = Results.cbegin(); iter != Results.cend(); iter++)
	{
		if((*iter)->Return)
		{
			file << "1";
			output.Trues += (unsigned long long)1 << (unsigned long long)i;
			assert(this->sat->Evaluate((*iter)->Result));
		}
		else if((*iter)->Equalility->empty() && (*iter)->Undecidable->empty())
		{
			file << "-1";
			output.Falses += (unsigned long long)1 << (unsigned long long)i;
			assert(!this->sat->Evaluate((*iter)->Result));
		}
		else
		{
			file << "0";
			output.Unknowns += (unsigned long long)1 << (unsigned long long)i;
			assert(!this->sat->Evaluate((*iter)->Result));
		}

		list<unsigned int>::iterator y;

		//Output Undeciable list
		y = (*iter)->Undecidable->begin();
		file << "(";
		if(y != (*iter)->Undecidable->end())
		{
			file << *y;
			y++;
			for(;y != (*iter)->Undecidable->end(); y++)
			{
				file << "|" << *y;
			}
		}
		file << ")";

		//Output Equalility list
		y = (*iter)->Equalility->begin();
		file << "(";
		if(y != (*iter)->Equalility->end())
		{
			file << *y;
			y++;
			for(;y != (*iter)->Equalility->end(); y++)
			{
				file << "|" << *y;
			}
		}
		file << ")";

		file << ",";
		delete (*iter)->Equalility;
		delete (*iter)->Undecidable;
		delete (*iter)->Result;
		delete (*iter);

		i++;
	}
	return output;
#endif
}