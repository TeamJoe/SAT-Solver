#include "Variable.h"

//For checking that all output is correct
#include <assert.h>

//Memory leak detection
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#include "Debug.h"

#ifdef _DEBUG
#define new DEBUG_CLIENTBLOCK
#endif

//******************************
//------------------------------
//
// CONSTRUCTORS
//
//------------------------------
//******************************
Variable::Variable(const int Variable_Number, SAT * _parent)
{
	assert(Variable_Number != 0);
	this->Variable_Number = Variable_Number;

	if(this->Variable_Number < 0)
	{
		this->Variable_Number *= -1;
	}
	assert(this->Variable_Number > 0);

	this->isEvaluated = false;
	this->_parent = _parent;
}
Variable::~Variable()
{
	assert(this->Variable_Number != 0);
	while(this->Positives.size() > 0)
	{
		assert((*this->Positives.cbegin())->variable = this);
		delete *this->Positives.cbegin();
	}
	while(this->Negatives.size() > 0)
	{
		assert((*this->Negatives.cbegin())->variable = this);
		delete *this->Negatives.cbegin();
	}
	while(this->InactivePositives.size() > 0)
	{
		assert((*this->InactivePositives.cbegin())->variable = this);
		delete *this->InactivePositives.cbegin();
	}
	while(this->InactiveNegatives.size() > 0)
	{
		assert((*this->InactiveNegatives.cbegin())->variable = this);
		delete *this->InactiveNegatives.cbegin();
	}
	assert(this->Positives.size() == 0);
	assert(this->Negatives.size() == 0);
	assert(this->InactivePositives.size() == 0);
	assert(this->InactiveNegatives.size() == 0);
	this->PreviousStates.clear();
	this->Variable_Number = 0;
}

//******************************
//------------------------------
//
// MODIFIERS
//
//------------------------------
//******************************

void Variable::Revert()
{
	while(this->InactivePositives.size() > 0)
	{
		this->Add(this->InactivePositives.cbegin());
	}
	while(this->InactiveNegatives.size() > 0)
	{
		this->Add(this->InactiveNegatives.cbegin());
	}
	this->PreviousStates.clear();
	assert(this->PreviousStates.size() == 0);
	assert(this->InactivePositives.size() == 0);
	assert(this->InactiveNegatives.size() == 0);
}

//a debugging sanity check function
bool doesListContain(Literal * lit, list <Literal *> search)
{
	for(list <Literal *>::const_iterator i = search.cbegin(); i != search.cend(); i++)
	{
		if(*i == lit)
		{
			return true;
		}
	}
	return false;
}

//only used during construction
void Variable::Add(Literal * lit)
{
	assert(lit);
	assert(lit->Contains(this, true) || lit->Contains(this, false));
	if(lit->GetType())
	{
		this->Positives.push_back(lit);
		lit->SetListPointer((--this->Positives.end()), true);

		assert(!doesListContain(lit, this->InactivePositives));
		assert(doesListContain(lit, this->Positives));
		assert(!doesListContain(lit, this->InactiveNegatives));
		assert(!doesListContain(lit, this->Negatives));
	}
	else
	{
		this->Negatives.push_back(lit);
		lit->SetListPointer((--this->Negatives.end()), true);

		assert(!doesListContain(lit, this->InactivePositives));
		assert(!doesListContain(lit, this->Positives));
		assert(!doesListContain(lit, this->InactiveNegatives));
		assert(doesListContain(lit, this->Negatives));
	}
	assert(lit->IsActive());
}
void Variable::Remove(list <Literal *>::const_iterator litIter)
{
	Literal * lit = *litIter;
	assert(lit);
	assert(lit->Contains(this));
	assert(lit->clause);
	if(lit->GetType())
	{
		assert(!doesListContain(lit, this->InactiveNegatives));
		assert(!doesListContain(lit, this->Negatives));
		if(lit->IsActive())
		{
			assert(!doesListContain(lit, this->InactivePositives));
			assert(doesListContain(lit, this->Positives));
			this->Positives.erase(litIter);
		}
		else
		{
			assert(doesListContain(lit, this->InactivePositives));
			assert(!doesListContain(lit, this->Positives));
			this->InactivePositives.erase(litIter);
		}
	}
	else
	{
		assert(!doesListContain(lit, this->InactivePositives));
		assert(!doesListContain(lit, this->Positives));
		if(lit->IsActive())
		{
			assert(!doesListContain(lit, this->InactiveNegatives));
			assert(doesListContain(lit, this->Negatives));
			this->Negatives.erase(litIter);
		}
		else
		{
			assert(doesListContain(lit, this->InactiveNegatives));
			assert(!doesListContain(lit, this->Negatives));
			this->InactiveNegatives.erase(litIter);
		}
	}

	assert(!doesListContain(lit, this->InactivePositives));
	assert(!doesListContain(lit, this->Positives));
	assert(!doesListContain(lit, this->InactiveNegatives));
	assert(!doesListContain(lit, this->Negatives));
	assert(lit->IsActive());
}
void Variable::Add(list <Literal *>::const_iterator litIter)
{
	Literal * lit = *litIter;
	assert(lit);
	assert(lit->Contains(this));
	assert(lit->clause);
	assert(!lit->IsActive());
	if(lit->GetType())
	{
		assert(doesListContain(lit, this->InactivePositives));
		assert(!doesListContain(lit, this->Positives));
		assert(!doesListContain(lit, this->InactiveNegatives));
		assert(!doesListContain(lit, this->Negatives));

		this->Positives.push_back(lit);
		lit->SetListPointer((--this->Positives.end()), true);
		this->InactivePositives.erase(litIter);

		assert(!doesListContain(lit, this->InactivePositives));
		assert(doesListContain(lit, this->Positives));
		assert(!doesListContain(lit, this->InactiveNegatives));
		assert(!doesListContain(lit, this->Negatives));
	}
	else
	{
		assert(!doesListContain(lit, this->InactivePositives));
		assert(!doesListContain(lit, this->Positives));
		assert(doesListContain(lit, this->InactiveNegatives));
		assert(!doesListContain(lit, this->Negatives));

		this->Negatives.push_back(lit);
		lit->SetListPointer((--this->Negatives.end()), true);
		this->InactiveNegatives.erase(litIter);

		assert(!doesListContain(lit, this->InactivePositives));
		assert(!doesListContain(lit, this->Positives));
		assert(!doesListContain(lit, this->InactiveNegatives));
		assert(doesListContain(lit, this->Negatives));
	}
	assert(lit->IsActive());
}
void Variable::Subtract(list <Literal *>::const_iterator litIter)
{
	Literal * lit = *litIter;
	assert(lit);
	assert(lit->Contains(this));
	assert(lit->clause);
	assert(lit->IsActive());
	if(lit->GetType())
	{
		assert(!doesListContain(lit, this->InactivePositives));
		assert(doesListContain(lit, this->Positives));
		assert(!doesListContain(lit, this->InactiveNegatives));
		assert(!doesListContain(lit, this->Negatives));

		this->InactivePositives.push_back(lit);
		lit->SetListPointer(--this->InactivePositives.end(), false);
		this->Positives.erase(litIter);

		assert(doesListContain(lit, this->InactivePositives));
		assert(!doesListContain(lit, this->Positives));
		assert(!doesListContain(lit, this->InactiveNegatives));
		assert(!doesListContain(lit, this->Negatives));
	}
	else
	{
		assert(!doesListContain(lit, this->InactivePositives));
		assert(!doesListContain(lit, this->Positives));
		assert(!doesListContain(lit, this->InactiveNegatives));
		assert(doesListContain(lit, this->Negatives));

		this->InactiveNegatives.push_back(lit);
		lit->SetListPointer(--this->InactiveNegatives.end(), false);
		this->Negatives.erase(litIter);

		assert(!doesListContain(lit, this->InactivePositives));
		assert(!doesListContain(lit, this->Positives));
		assert(doesListContain(lit, this->InactiveNegatives));
		assert(!doesListContain(lit, this->Negatives));
	}
	assert(!lit->IsActive());
}
bool Variable::IsEvaluated() const
{
	return this->isEvaluated;
}
void Variable::StepBack()
{
	this->PreviousStates.pop_back();
}
bool Variable::Flip()
{
	this->isEvaluated = false;

	for(list <Literal *>::const_iterator iter = this->InactivePositives.cbegin(); iter != this->InactivePositives.cend();)
	{
		Literal * lit = *iter;
		iter++;
		assert(lit->Contains(this));
		lit->Undo();
	}
	for(list <Literal *>::const_iterator iter = this->InactiveNegatives.cbegin(); iter != this->InactiveNegatives.cend();)
	{
		Literal * lit = *iter;
		iter++;
		assert(lit->Contains(this));
		lit->Undo();
	}

	if(!this->WentPositive)
	{
		while(this->Positives.size() > 0)
		{
			Literal * lit = *this->Positives.cbegin();
			assert(lit->Contains(this));
			lit->RemoveFromClause();
		}
		while(this->Negatives.size() > 0)
		{
			Literal * lit = * this->Negatives.cbegin();
			assert(lit->Contains(this));
			lit->RemoveFromVariable();
		}

		assert(this->Positives.size() == 0);
		assert(this->Negatives.size() == 0);

		this->WentPositive = true;
	}
	else
	{
		while(this->Positives.size() > 0)
		{
			Literal * lit = *this->Positives.cbegin();
			assert(lit->Contains(this));
			lit->RemoveFromVariable();
		}
		while(this->Negatives.size() > 0)
		{
			Literal * lit = * this->Negatives.cbegin();
			assert(lit->Contains(this));
			lit->RemoveFromClause();
		}

		assert(this->Positives.size() == 0);
		assert(this->Negatives.size() == 0);

		this->WentPositive = false;
	}

	this->isEvaluated = true;

	return this->WentPositive;
}
bool Variable::Undo()
{
	this->isEvaluated = false;

	for(list <Literal *>::const_iterator iter = this->InactivePositives.cbegin(); iter != this->InactivePositives.cend();)
	{
		Literal * lit = *iter;
		iter++;
		assert(lit->Contains(this));
		lit->Undo();
	}
	for(list <Literal *>::const_iterator iter = this->InactiveNegatives.cbegin(); iter != this->InactiveNegatives.cend();)
	{
		Literal * lit = *iter;
		iter++;
		assert(lit->Contains(this));
		lit->Undo();
	}

	this->_parent->Remove(this->listPointer, true);
	assert(this->isActive == true);

	return this->WentPositive;
}
void Variable::Remove(bool isPositive)
{
	if(isPositive)
	{
		while(this->Positives.size() > 0)
		{
			Literal * lit = *this->Positives.cbegin();
			assert(lit->Contains(this));
			lit->RemoveFromClause();
		}
		while(this->Negatives.size() > 0)
		{
			Literal * lit = * this->Negatives.cbegin();
			assert(lit->Contains(this));
			lit->RemoveFromVariable();
		}

		assert(this->Positives.size() == 0);
		assert(this->Negatives.size() == 0);

		this->WentPositive = true;
	}
	else
	{
		while(this->Positives.size() > 0)
		{
			Literal * lit = *this->Positives.cbegin();
			assert(lit->Contains(this));
			lit->RemoveFromVariable();
		}
		while(this->Negatives.size() > 0)
		{
			Literal * lit = * this->Negatives.cbegin();
			assert(lit->Contains(this));
			lit->RemoveFromClause();
		}

		assert(this->Positives.size() == 0);
		assert(this->Negatives.size() == 0);

		this->WentPositive = false;
	}
	this->isEvaluated = true;
	this->_parent->Remove(this->listPointer, false);

	assert(this->WentPositive == isPositive);
	assert(this->isActive == false);
}
void Variable::Set()
{
	this->PreviousStates.push_back(this->CurrentState);
}
void Variable::Update()
{
	this->CurrentState.NegativesSize = this->Negatives.size();
	this->CurrentState.PositivesSize = this->Positives.size();
	this->CurrentState.LargestNegativeClauseCount = 0;
	this->CurrentState.LargestPositiveClauseCount = 0;
	this->CurrentState.LargestNegativeClauseSize = 0;
	this->CurrentState.LargestPositiveClauseSize = 0;
	this->CurrentState.SmallestNegativeClauseCount = 0;
	this->CurrentState.SmallestPositiveClauseCount = 0;
	this->CurrentState.SmallestNegativeClauseSize = 0xFFFFFFFF;
	this->CurrentState.SmallestPositiveClauseSize = 0xFFFFFFFF;

	//Check the positive literals
	for(list <Literal *>::const_iterator iter = this->Positives.cbegin(); iter != this->Positives.cend(); iter++)
	{
		assert((*iter)->Contains(this));
		//Largest
		if((*iter)->ClauseSize() == this->CurrentState.LargestPositiveClauseSize)
		{
			this->CurrentState.LargestPositiveClauseCount++;
		}
		else if((*iter)->ClauseSize() > this->CurrentState.LargestPositiveClauseSize)
		{
			this->CurrentState.LargestPositiveClauseCount = 1;
			this->CurrentState.LargestPositiveClauseSize = (*iter)->ClauseSize();
		}

		//Smallest
		if((*iter)->ClauseSize() == this->CurrentState.SmallestPositiveClauseSize)
		{
			this->CurrentState.SmallestPositiveClauseCount++;
		}
		else if((*iter)->ClauseSize() < this->CurrentState.SmallestPositiveClauseSize)
		{
			this->CurrentState.SmallestPositiveClauseCount = 1;
			this->CurrentState.SmallestPositiveClauseSize = (*iter)->ClauseSize();
		}
	}

	//Check the negative literals
	for(list <Literal *>::const_iterator iter = this->Negatives.cbegin(); iter != this->Negatives.cend(); iter++)
	{
		assert((*iter)->Contains(this));
		//Largest
		if((*iter)->ClauseSize() == this->CurrentState.LargestNegativeClauseSize)
		{
			this->CurrentState.LargestNegativeClauseCount++;
		}
		else if((*iter)->ClauseSize() > this->CurrentState.LargestNegativeClauseSize)
		{
			this->CurrentState.LargestNegativeClauseCount = 1;
			this->CurrentState.LargestNegativeClauseSize = (*iter)->ClauseSize();
		}

		//Smallest
		if((*iter)->ClauseSize() == this->CurrentState.SmallestNegativeClauseSize)
		{
			this->CurrentState.SmallestNegativeClauseCount++;
		}
		else if((*iter)->ClauseSize() < this->CurrentState.SmallestNegativeClauseSize)
		{
			this->CurrentState.SmallestNegativeClauseCount = 1;
			this->CurrentState.SmallestNegativeClauseSize = (*iter)->ClauseSize();
		}
	}
}


void Variable::SetListPointer(list <Variable *>::const_iterator var, bool isActive)
{
	assert(*var == this);
	this->listPointer = var;
	this->isActive = isActive;
}


//******************************
//------------------------------
//
// OPERATIONS
//
//------------------------------
//******************************

int Variable::GetVariable() const
{
	return this->Variable_Number;
}

bool Variable::IsActive() const
{
	return this->isActive;
}

int Variable::GetValue() const
{
	if(this->isEvaluated)
	{
		return WentPositive ? this->Variable_Number : (-1 * this->Variable_Number);
	}
	else
	{
		return 0;
	}
}

//Comparisons
unsigned int Variable::LargestNumber() const
{
	return this->CurrentState.NegativesSize > this->CurrentState.PositivesSize 
		? this->CurrentState.NegativesSize 
		: this->CurrentState.PositivesSize;
}
unsigned int Variable::SmallestNumber() const
{
	return this->CurrentState.NegativesSize < this->CurrentState.PositivesSize 
		? this->CurrentState.NegativesSize 
		: this->CurrentState.PositivesSize;
}
unsigned int Variable::GetDifference() const
{
	return this->CurrentState.NegativesSize > this->CurrentState.PositivesSize
		? this->CurrentState.NegativesSize - this->CurrentState.PositivesSize
		: this->CurrentState.PositivesSize - this->CurrentState.NegativesSize;
}
unsigned int Variable::SmallestClauseSize() const
{
	return this->CurrentState.SmallestNegativeClauseSize < this->CurrentState.SmallestPositiveClauseSize
		? this->CurrentState.SmallestNegativeClauseSize
		: this->CurrentState.SmallestPositiveClauseSize;
}
unsigned int Variable::SmallestClauseCount() const
{
	return this->CurrentState.SmallestNegativeClauseSize == this->CurrentState.SmallestPositiveClauseSize
		? this->CurrentState.SmallestNegativeClauseCount + this->CurrentState.SmallestPositiveClauseCount
		: this->CurrentState.SmallestNegativeClauseSize < this->CurrentState.SmallestPositiveClauseSize
			? this->CurrentState.SmallestNegativeClauseCount
			: this->CurrentState.SmallestPositiveClauseCount;
}
unsigned int Variable::LargestClauseSize() const
{
	return this->CurrentState.LargestNegativeClauseSize > this->CurrentState.LargestPositiveClauseSize
		? this->CurrentState.LargestNegativeClauseSize
		: this->CurrentState.LargestPositiveClauseSize;
}
unsigned int Variable::LargestClauseCount() const
{
	return this->CurrentState.LargestNegativeClauseSize == this->CurrentState.LargestPositiveClauseSize
		? this->CurrentState.LargestNegativeClauseCount + this->CurrentState.LargestPositiveClauseCount
		: this->CurrentState.LargestNegativeClauseSize > this->CurrentState.LargestPositiveClauseSize
			? this->CurrentState.LargestNegativeClauseCount
			: this->CurrentState.LargestPositiveClauseCount;
}
unsigned int Variable::GetNegativesSize() const
{
	return this->CurrentState.NegativesSize;
}
unsigned int Variable::GetPositivesSize() const
{
	return this->CurrentState.PositivesSize;
}
unsigned int Variable::GetSmallestNegativeClauseSize() const
{
	return this->CurrentState.SmallestNegativeClauseSize;
}
unsigned int Variable::GetSmallestNegativeClauseCount() const
{
	return this->CurrentState.SmallestNegativeClauseCount;
}
unsigned int Variable::GetSmallestPositiveClauseCount() const
{
	return this->CurrentState.SmallestPositiveClauseCount;
}
unsigned int Variable::GetSmallestPositiveClauseSize() const
{
	return this->CurrentState.SmallestPositiveClauseSize;
}
unsigned int Variable::GetLargestNegativeClauseSize() const
{
	return this->CurrentState.LargestNegativeClauseSize;
}
unsigned int Variable::GetLargestNegativeClauseCount() const
{
	return this->CurrentState.LargestNegativeClauseCount;
}
unsigned int Variable::GetLargestPositiveClauseSize() const
{
	return this->CurrentState.LargestPositiveClauseSize;
}
unsigned int Variable::GetLargestPositiveClauseCount() const
{
	return this->CurrentState.LargestPositiveClauseCount;
}

//******************************
//------------------------------
//
// OPERATOR OVERLOADS
//
//------------------------------
//******************************
bool Variable::operator==(const Variable & variable) const
{
	return this->Variable_Number == variable.Variable_Number;
}
bool Variable::operator!=(const Variable & variable) const
{
	return this->Variable_Number != variable.Variable_Number;
}
bool Variable::operator<(const Variable & variable) const
{
	return this->Variable_Number < variable.Variable_Number;
}
bool Variable::operator>(const Variable & variable) const
{
	return this->Variable_Number > variable.Variable_Number;
}
bool Variable::operator<=(const Variable & variable) const
{
	return this->Variable_Number <= variable.Variable_Number;
}
bool Variable::operator>=(const Variable & variable) const
{
	return this->Variable_Number >= variable.Variable_Number;
}