#ifndef CONSTANTS_H
#define CONSTANTS_H

//#define KEEP_VARIABLE_HISTORY

#define DEPTH
//#define DEPTH_USES_FLIP
#define DEPTH_FULL_EVAL
//#define FLIP
//#define FAST
#define END_ON_FIRST_SOLUTION

//#define ORGINAL_SET
#define SECONDARY_SET

#ifdef _DEBUG
//#define OUTPUT_INTERMEDIATE_SOLUTION
#define MAX_DEPTH_LIMIT 300
#else
#define MAX_DEPTH_LIMIT 100000000
#endif

#define PARALLEL
//#define COMPLETE


#endif