char ToUpper(char c);
char ToLower(char c);