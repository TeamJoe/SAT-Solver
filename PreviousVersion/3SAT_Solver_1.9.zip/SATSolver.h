class SATSolver;

#ifndef SATSOLVER_H
#define SATSOLVER_H

#include <fstream>

#include "SAT.h"

using namespace std;

struct ReturnValue
{
	unsigned long long Trues;
	unsigned long long Falses;
	unsigned long long Unknowns;
};

struct Pair
{
	bool Return;
	list<int> * Result;
	list<unsigned int> * Equalility;
	list<unsigned int> * Undecidable;
};

struct DepthPair
{
	int Return;
	unsigned long long EvalCount;
	list<int> * Result;
};

#define DEPTH
//#define DEPTH_USES_FLIP
//#define FLIP
//#define FAST

#define MAX_DEPTH_LIMIT 100000

class SATSolver
{
private:
	SAT * sat;
	Pair * FlipSat(int (Decider)(Variable *), const list <SortFunction *> * SortFunctions) const;
	DepthPair * DepthSat(int (Decider)(Variable *), const list <SortFunction *> * SortFunctions) const;
	void _DepthSat(int (Decider)(Variable *), const list <SortFunction *> * SortFunctions, DepthPair * a, bool reversed) const;
	Pair * FastSat(int (Decider)(Variable *), const list <SortFunction *> * SortFunctions) const;
public:
	SATSolver(SAT * sat);
	~SATSolver();
	//list <string> & SlowSat();
	ReturnValue SolveTruth(ofstream & file) const;
};

#endif