#include <list>
#include <string>
#include <fstream>

#include "Variable.h"
#include "Clause.h"
#include "SAT.h"

//For checking that all output is correct
#include <assert.h>

//Memory leak detection
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#include "Debug.h"

#ifdef _DEBUG
#define new DEBUG_CLIENTBLOCK
#endif

using namespace std;

//******************************
//------------------------------
//
// CONSTRUCTORS
//
//------------------------------
//******************************

SAT::SAT(const char * input, const bool isCNF)
{
	//Create intial information
	ifstream file;
	file.open(input);
	if(file.is_open())
	{
		if(isCNF)
		{
			if(!this->ReadCNF(file))
			{
				this->cleanVariables();
				this->cleanClauses();
				return;
			}
		}
		else
		{
			if(!this->ReadFrom(file))
			{
				this->cleanVariables();
				this->cleanClauses();
				return;
			}
		}
	}
	file.close();

	this->ClauseRemaining = 0;
}
SAT::~SAT()
{
}

void SAT::Revert()
{
	while(this->previousVariables.size() > 0)
	{
		this->variables.push_back(*this->previousVariables.cbegin());
		this->previousVariables.pop_front();
	}
	for(list <Variable *>::const_iterator iter = this->variables.cbegin(); iter != this->variables.cend(); iter++)
	{
		(*iter)->Revert();
	}
	this->ClauseRemaining = 0;
}

void SAT::cleanVariables()
{
	for(list <Variable *>::const_iterator iter = this->previousVariables.cbegin(); iter != this->previousVariables.cend(); iter++)
	{
		delete *iter;
	}
	for(list <Variable *>::const_iterator iter = this->variables.cbegin(); iter != this->variables.cend(); iter++)
	{
		delete *iter;
	}
	this->previousVariables.clear();
	this->variables.clear();
}
void SAT::cleanClauses()
{
	for(list <Clause *>::const_iterator iter = this->clauses.cbegin(); iter != this->clauses.cend(); iter++)
	{
		delete *iter;
	}
	this->clauses.clear();
}

//******************************
//------------------------------
//
// PRIVATE FUNCTIONS
//
//------------------------------
//******************************
Clause * SAT::ContainsClause(const Clause * clause) const
{
	for(list <Clause *>::const_iterator iter = this->clauses.cbegin(); iter != this->clauses.cend(); iter++)
	{
		if(**iter == *clause)
		{
			return *iter;
		}
	}
	return NULL;
}
Variable * SAT::ContainsVariable(const Variable * variable) const
{
	for(list <Variable *>::const_iterator iter = this->variables.cbegin(); iter != this->variables.cend(); iter++)
	{
		if(**iter == *variable)
		{
			return *iter;
		}
	}
	return NULL;
}
int SAT::CharToInt(const char c) const
{
	if(c >= 'A' && c <= 'Z')
	{
		return (int)(c - 64);
	}
	else if(c >= 'a' && c <= 'z')
	{
		return (int)(-1 * (c - 96));
	}
	else
	{
		return (int)c;
	}
}

Variable * SAT::Sort(Variable * var1, Variable * var2, const list <SortFunction *> * SortFunctions) const
{
	list <SortFunction *>::const_iterator iter = SortFunctions->cbegin();
	for(; iter != SortFunctions->cend(); iter++)
	{
		if(!((*iter)->Eqaulity)(var1, var2))
		{
			return ((*iter)->Sort)(var1, var2);
		}
	}
	return ((*(--iter))->Sort)(var1, var2);
}

//******************************
//------------------------------
//
// READ INPUT FUNCTIONS
//
//------------------------------
//******************************
bool SAT::ReadFrom(ifstream & file)
{
	if(file.eof())
	{
		return false;
	}

	//Read Input
	unsigned int length;
	file >> length;
	for(unsigned int i = 0; i < length; i++)
	{
		string s;
		file >> s;
		if(file.eof())
		{
			assert(false);
			return false;
		}
		if(s.size() > 0)
		{
			list <Literal *> clause;
			for(unsigned int i = 0; i < s.size(); i++)
			{
				Variable * var = new Variable(CharToInt(s[i]));
				Variable * v = ContainsVariable(var);
				if(!v)
				{
					clause.push_back(new Literal(var, NULL, CharToInt(s[i]) > 0));
					this->variables.push_back(var);
				}
				else
				{
					clause.push_back(new Literal(v, NULL, CharToInt(s[i]) > 0));
					delete var;
				}
			}

			assert(clause.size());
			Clause * cla = new Clause(&clause);
			assert(cla);
			assert(cla->IntialSize());
			if(cla->isValid() && !ContainsClause(cla))
			{
				this->clauses.push_back(cla);
			}
			else
			{
				while(clause.size() > 0)
				{
					delete *clause.cbegin();
					clause.pop_front();
				}
				delete cla;
			}
		}
	}
	return true;
}
bool SAT::ReadCNF(ifstream & file)
{
	if(file.eof())
	{
		return false;
	}

	while(true)
	{
		string s;
		file >> s;
		if(file.eof())
		{
			assert(false);
			return false;
		}
		if(s == "p")
		{
			file >> s;
			if(file.eof() || s != "cnf")
			{
				assert(false);
				return false;
			}
			break;
		}
	}

	unsigned int VarCount, ClauseCount;
	file >> VarCount >> ClauseCount;

	//Read inputs
	list <Literal *> clause;
	for(unsigned int i = 0; i < ClauseCount; i++)
	{
		clause.clear();
		int s;
		file >> s;
		if(file.eof())
		{
			assert(false);
			Clause * cla = new Clause(&clause);
			delete cla;
			return false;
		}
		while(s != 0)
		{
			Variable * var = new Variable(s);
			assert(var);
			Variable * v = ContainsVariable(var);
			if(!v)
			{
				clause.push_back(new Literal(var, NULL, s > 0));
				this->variables.push_back(var);
			}
			else
			{
				clause.push_back(new Literal(v, NULL, s > 0));
				delete var;
			}

			file >> s;
		}

		assert(clause.size());
		Clause * cla = new Clause(&clause);
		assert(cla);
		assert(cla->IntialSize());
		if(cla->isValid() && !ContainsClause(cla))
		{
			this->clauses.push_back(cla);
		}
		else
		{
			while(clause.size() > 0)
			{
				delete *clause.cbegin();
				clause.pop_front();
			}
			delete cla;
		}
	}

	assert(VarCount == this->variables.size());

	//There are repeats in the files, do not know why
	//assert(ClauseCount == this->clauses.size());

	return true;
}

//******************************
//------------------------------
//
// CHECKER FUNCTIONS
//
//------------------------------
//******************************
bool SAT::isValid() const
{
	return this->clauses.size() > 0 && this->variables.size() > 0;
}

bool SAT::Evaluate(const list <int> * variables) const
{
	for(list <Clause *>::const_iterator iter = this->clauses.cbegin(); iter != this->clauses.cend(); iter++)
	{
		if(!(*iter)->Evaluate(variables))
		{
			return false;
		}
	}
	return true;
}

//******************************
//------------------------------
//
// SOLVER FUNCTIONS
//
//------------------------------
//******************************
void SAT::UpdateVariables()
{
	for(list <Variable *>::const_iterator iter = this->variables.cbegin(); iter != this->variables.cend(); iter++)
	{
		(*iter)->Update();
	}
}
void SAT::SetVariables()
{
	for(list <Variable *>::const_iterator iter = this->variables.cbegin(); iter != this->variables.cend(); iter++)
	{
		(*iter)->Set();
	}
}

Variable * SAT::NextVariable(const list <SortFunction *> * SortFunctions) const
{
	Variable * val = this->variables.front();
	for(list <Variable *>::const_iterator iter = this->variables.cbegin(); iter != this->variables.cend(); iter++)
	{
		val = this->Sort(val, *iter, SortFunctions);
	}
	return val;
}

Variable * SAT::NextVariable(const Variable * Excluded_Variable, const list <SortFunction *> * SortFunctions) const
{
	Variable * val = this->variables.front();
	for(list <Variable *>::const_iterator iter = this->variables.cbegin(); iter != this->variables.cend(); iter++)
	{
		if(*iter != Excluded_Variable)
		{
			val = this->Sort(val, *iter, SortFunctions);
		}
	}
	return val;
}

void SAT::RemoveVariable(Variable * var, const bool isPositive)
{
	//Count number of clauses being deleted
	if(isPositive)
	{
		this->ClauseRemaining += var->GetPositivesSize();
	}
	else
	{
		this->ClauseRemaining += var->GetNegativesSize();
	}

	//Remove the variable
	var->Remove(isPositive);
	this->variables.remove(var);
	this->previousVariables.push_back(var);
}

unsigned int SAT::ClauseCount() const
{
	assert(this->ClauseRemaining <= this->clauses.size());
	return this->clauses.size() - this->ClauseRemaining;
}

unsigned int SAT::VariableCount() const
{
	return this->variables.size();
}