class Clause;

#ifndef CLAUSE_H
#define CLAUSE_H

#include <list>
#include "Literal.h"

using namespace std;

class Clause
{
private:
	Literal ** clause;
	unsigned int _size;
public:

	//Constructors
	Clause(const list <Literal *> * clause);
	~Clause();

	//Operations
	unsigned int IntialSize() const;
	unsigned int Size() const;
	bool Contains(const Variable * variable) const;
	bool Contains(const Variable * variable, const bool isPositive) const;
	bool Contains(const Literal * lit) const;
	bool Evaluate(const list <int> * variables) const;
	bool isValid() const;

	//Modifers
	void Remove();

	//Operator Overloads
	bool operator==(const Clause & clause) const;
	bool operator!=(const Clause & clause) const;
	bool operator<(const Clause & clause) const;
	bool operator>(const Clause & clause) const;
	bool operator<=(const Clause & clause) const;
	bool operator>=(const Clause & clause) const;
};

#endif