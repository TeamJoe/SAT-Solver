#include <list>
#include "Clause.h"

//For checking that all output is correct
#include <assert.h>

//Memory leak detection
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#include "Debug.h"

#ifdef _DEBUG
#define new DEBUG_CLIENTBLOCK
#endif

using namespace std;

//******************************
//------------------------------
//
// CONSTRUCTORS
//
//------------------------------
//******************************
Clause::Clause(const list <Literal *> * clause)
{
	assert(clause);

	this->_size = (unsigned int)clause->size();
	if(this->_size == 0)
	{
		this->clause = NULL;
	}
	else
	{
		//this->clause = (Literal **)malloc(sizeof(Literal *) * this->_size);
		this->clause = new Literal * [this->_size];
	}

	assert(this->_size);
	assert(this->clause);

	unsigned int i = 0;
	for(list <Literal *>::const_iterator iter = clause->cbegin(); iter != clause->cend(); iter++)
	{
		assert(*iter);
		(*iter)->clause = this;

		//check for duplicates and opposites
		unsigned int y = 0;
		for(; y < i; y++)
		{
			//duplicate
			if(this->clause[y]->Contains(*iter))
			{
				y = 0xFFFFFFFF;
				delete *iter;
			}
			//opposite
			else if(this->clause[y]->Opposite(*iter))
			{
				this->_size = 0;
				for(list <Literal *>::const_iterator iter = clause->cbegin(); iter != clause->cend(); iter++)
				{
					delete *iter;
				}
				return;
			}
			else if(*this->clause[y] > **iter)
			{
				break;
			}
		}
		//if unique variable
		if(y != 0xFFFFFFFF)
		{
			//if needs to be inserted at end
			if(y == i)
			{
				this->clause[i++] = *iter;
				assert(this->clause[i-1]->clause == this);
			}
			//if needs to be inserted inside of list
			else
			{
				for(unsigned int z = i; ; z--)
				{
					this->clause[z+1] = this->clause[z];
					if(z <= y)
					{
						break;
					}
				}
				assert(this->clause[y]->clause == this);
				this->clause[y] = *iter;
				i++;
			}
		}
	}
	this->_size = i;
	assert(this->_size);
}
Clause::~Clause()
{
	assert(this->clause);
	//delete seems to freeze for an unknown reason
	//free(this->clause);
	//delete this->clause;
	this->clause = NULL;
	this->_size = 0;
}
//******************************
//------------------------------
//
// OPERATIONS
//
//------------------------------
//******************************
unsigned int Clause::IntialSize() const
{
	assert(this->_size);
	assert(this->clause);
	return this->_size;
}
unsigned int Clause::Size() const
{
	assert(this->_size);
	assert(this->clause);
	unsigned int size = 0;
	for(unsigned int i = 0; i < this->_size; i++)
	{
		if(this->clause[i]->IsActive())
		{
			size++;
		}
	}
	return size;
}
bool Clause::Contains(const Variable * variable) const
{
	assert(this->_size);
	assert(this->clause);
	for(unsigned int i = 0; i < this->_size; i++)
	{
		assert(this->clause[i]->clause == this);
		if(this->clause[i]->Contains(variable))
		{
			return true;
		}
	}
	return false;
}
bool Clause::Contains(const Variable * variable, const bool isPositive) const
{
	assert(this->_size);
	assert(this->clause);
	for(unsigned int i = 0; i < this->_size; i++)
	{
		assert(this->clause[i]->clause == this);
		if(this->clause[i]->Contains(variable, isPositive))
		{
			return true;
		}
	}
	return false;
}
bool Clause::Contains(const Literal * lit) const
{
	assert(this->_size);
	assert(this->clause);
	for(unsigned int i = 0; i < this->_size; i++)
	{
		//assert(this->clause[i]->clause == this);
		if(this->clause[i]->Contains(lit))
		{
			return true;
		}
	}
	return false;
}
bool Clause::Evaluate(const list <int> * variables) const
{
	assert(this->_size);
	assert(this->clause);
	if(this->_size < variables->size())
	{
		for(list <int>::const_iterator variable_iter = variables->cbegin(); variable_iter != variables->cend(); variable_iter++)
		{
			for(unsigned int i = 0; i < this->_size; i++)
			{
				assert(this->clause[i]->clause == this);
				if(this->clause[i]->Value == *variable_iter)
				{
					return true;
				}
			}
		}
		return false;
	}
	else
	{
		for(unsigned int i = 0; i < this->_size; i++)
		{
			for(list <int>::const_iterator variable_iter = variables->cbegin(); variable_iter != variables->cend(); variable_iter++)
			{
				assert(this->clause[i]->clause == this);
				if(this->clause[i]->Value == *variable_iter)
				{
					return true;
				}
			}
		}
		return false;
	}
}
bool Clause::isValid() const
{
	return this->_size > 0;
}

//******************************
//------------------------------
//
// MODIFIERS
//
//------------------------------
//******************************
void Clause::Remove()
{
	assert(this->_size);
	assert(this->clause);
	for(unsigned int i = 0; i < this->_size; i++)
	{
		assert(this->clause[i]->clause == this);
		this->clause[i]->RemoveFromVariable();
		assert(!this->clause[i]->IsActive());
	}
}


//******************************
//------------------------------
//
// OPERATOR OVERLOADS
//
//------------------------------
//******************************
bool Clause::operator==(const Clause & clause) const
{
	assert(this->_size);
	assert(this->clause);
	assert(clause._size);
	assert(clause.clause);
	if(this->_size != clause._size)
	{
		return false;
	}
	for(unsigned int i = 0; i < this->_size; i++)
	{
		if(!this->clause[i]->Contains(clause.clause[i]))
		{
			assert(this->clause[i]->clause == this);
			return false;
		}
	}
	return true;
}
bool Clause::operator!=(const Clause & clause) const
{
	assert(this->_size);
	assert(this->clause);
	assert(clause._size);
	assert(clause.clause);
	return !(*this == clause);
}
bool Clause::operator<(const Clause & clause) const
{
	assert(this->_size);
	assert(this->clause);
	assert(clause._size);
	assert(clause.clause);
	if(this->_size != clause._size)
	{
		return this->_size < clause._size;
	}
	for(unsigned int i = 0; i < this->_size; i++)
	{
		if(!this->clause[i]->Contains(clause.clause[i]))
		{
			assert(this->clause[i]->clause == this);
			return *this->clause[i] < *clause.clause[i];
		}
	}
	return false;
}
bool Clause::operator>(const Clause & clause) const
{
	assert(this->_size);
	assert(this->clause);
	assert(clause._size);
	assert(clause.clause);
	if(this->_size != clause._size)
	{
		return this->_size < clause._size;
	}
	for(unsigned int i = 0; i < this->_size; i++)
	{
		if(!this->clause[i]->Contains(clause.clause[i]))
		{
			assert(this->clause[i]->clause == this);
			return *this->clause[i] > *clause.clause[i];
		}
	}
	return false;
}
bool Clause::operator<=(const Clause & clause) const
{
	assert(this->_size);
	assert(this->clause);
	assert(clause._size);
	assert(clause.clause);
	return !(*this > clause);
}
bool Clause::operator>=(const Clause & clause) const
{
	assert(this->_size);
	assert(this->clause);
	assert(clause._size);
	assert(clause.clause);
	return !(*this < clause);
}