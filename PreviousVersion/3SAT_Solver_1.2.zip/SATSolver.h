class SATSolver;

#ifndef SATSOLVER_H
#define SATSOLVER_H

#include <fstream>

#include "SAT.h"

using namespace std;

struct ReturnValue
{
	unsigned long long Trues;
	unsigned long long Falses;
	unsigned long long Unknowns;
};

struct Pair
{
	bool Return;
	list<int> * Result;
	list<unsigned int> * Equalility;
	list<unsigned int> * Undecidable;
};

class SATSolver
{
private:
	SAT * sat;
	Pair * FastSat(int (Decider)(Variable *), const list <SortFunction *> * SortFunctions) const;
public:
	SATSolver(SAT * sat);
	~SATSolver();
	//list <string> & SlowSat();
	ReturnValue SATSolver::SolveTruth(ofstream & file) const;
};

#endif